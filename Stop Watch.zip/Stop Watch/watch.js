let startTime = 0;
let elapsedTime = 0;
let timerInterval;
let isRunning = false;
let lapCount = 0;
let splitCount = 0;

const startStopBtn = document.getElementById('startStopBtn');
const resetBtn = document.getElementById('resetBtn');
const lapBtn = document.getElementById('lapBtn');
const splitBtn = document.getElementById('splitBtn');
const clearLapsBtn = document.getElementById('clearLapsBtn');
const display = document.getElementById('display');
const laps = document.getElementById('laps');

// Function to format time as a string "HH:MM:SS.mm"
function formatTime(time) {
  const hours = Math.floor(time / (1000 * 60 * 60));
  const minutes = Math.floor((time % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((time % (1000 * 60)) / 1000);
  const milliseconds = Math.floor((time % 1000) / 10);

  return (
    (hours < 10 ? '0' : '') + hours + ':' +
    (minutes < 10 ? '0' : '') + minutes + ':' +
    (seconds < 10 ? '0' : '') + seconds + '.' +
    (milliseconds < 10 ? '0' : '') + milliseconds
  );
}

// Function to start or stop the stopwatch
function startStop() {
  if (!isRunning) {
    startTime = Date.now() - elapsedTime;
    timerInterval = setInterval(updateTime, 10);
    startStopBtn.textContent = 'Pause';
    isRunning = true;
    resetBtn.disabled = true;
    lapBtn.disabled = false;
    splitBtn.disabled = false;
  } else {
    clearInterval(timerInterval);
    elapsedTime = Date.now() - startTime;
    startStopBtn.textContent = 'Start';
    isRunning = false;
    resetBtn.disabled = false;
    lapBtn.disabled = true;
    splitBtn.disabled = true;
  }
}

// Function to reset the stopwatch
function reset() {
  clearInterval(timerInterval);
  elapsedTime = 0;
  display.textContent = '00:00:00.00';
  startStopBtn.textContent = 'Start';
  isRunning = false;
  laps.innerHTML = '';
  lapCount = 0;
  splitCount = 0;
  lapBtn.disabled = true;
  splitBtn.disabled = true;
}

// Function to record a lap
function lap() {
  lapCount++;
  const lapTime = display.textContent;
  const li = document.createElement('li');
  li.textContent = `Lap ${lapCount}: ${lapTime}`;
  laps.appendChild(li);
}

// Function to split the stopwatch
function split() {
  splitCount++;
  const splitTime = display.textContent;
  const li = document.createElement('li');
  li.textContent = `Split ${splitCount}: ${splitTime}`;
  laps.appendChild(li);
}

// Function to clear all lap times
function clearLaps() {
  laps.innerHTML = '';
  lapCount = 0;
  splitCount = 0;
}

// Function to update the display with the current elapsed time
function updateTime() {
  elapsedTime = Date.now() - startTime;
  display.textContent = formatTime(elapsedTime);
}

// Event listeners for buttons
startStopBtn.addEventListener('click', startStop);
resetBtn.addEventListener('click', reset);
lapBtn.addEventListener('click', lap);
splitBtn.addEventListener('click', split);
clearLapsBtn.addEventListener('click', clearLaps);