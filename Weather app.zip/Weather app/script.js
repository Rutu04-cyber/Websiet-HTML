const apiKey = 'YOUR_OPENWEATHERMAP_API_KEY';
const cityInput = document.getElementById('city-input');
const getWeatherBtn = document.getElementById('get-weather-btn');
const cityNameElement = document.getElementById('city-name');
const weatherDescriptionElement = document.getElementById('weather-description');
const temperatureElement = document.getElementById('temperature');
const humidityElement = document.getElementById('humidity');
const windSpeedElement = document.getElementById('wind-speed');
const dateTimeElement = document.getElementById('date-time');

getWeatherBtn.addEventListener('click', getWeather);

function getWeather() {
    const city = cityInput.value.trim();
    if (city) {
        fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`)
            .then(response => response.json())
            .then(data => {
                if (data.cod === 200) {  // Check if the city was found
                    const weatherData = data.weather[0];
                    const temperature = data.main.temp;
                    const humidity = data.main.humidity;
                    const windSpeed = data.wind.speed;
                    const weatherDescription = weatherData.description;

                    cityNameElement.textContent = data.name;
                    weatherDescriptionElement.textContent = `Weather: ${weatherDescription}`;
                    temperatureElement.textContent = `Temperature: ${temperature}°C`;
                    humidityElement.textContent = `Humidity: ${humidity}%`;
                    windSpeedElement.textContent = `Wind Speed: ${windSpeed} m/s`;
                    dateTimeElement.textContent = `Date: ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}`;

                    // Link to OpenWeatherMap for detailed weather
                    cityNameElement.href = `https://openweathermap.org/city/${data.id}`;
                    cityNameElement.target = '_blank';  // Open link in a new tab
                } else {
                    alert('City not found! Please try again.');
                }
            })
            .catch(error => console.error('Error fetching weather data:', error));
    } else {
        alert('Please enter a city name.');
    }
}
