document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Thank you for contacting me!');
    // Add form submission logic here (e.g., send data to a server or API)
});
