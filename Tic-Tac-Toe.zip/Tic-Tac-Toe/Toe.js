let currentPlayer = 'X';
let gameBoard = ['', '', '', '', '', '', '', '', ''];
let gameOver = false;

function handleClick(cellIndex) {
    if (gameOver) return;

    if (gameBoard[cellIndex - 1] === '') {
        gameBoard[cellIndex - 1] = currentPlayer;
        document.getElementById(`cell-${cellIndex}`).innerHTML = currentPlayer;

        if (checkWin()) {
            gameOver = true;
            document.getElementById('game-status').innerHTML = `Player ${currentPlayer} wins!`;
            showFireworks();
        } else if (checkTie()) {
            gameOver = true;
            document.getElementById('game-status').innerHTML = 'It\'s a tie!';
        } else {
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
            document.getElementById('game-status').innerHTML = `Player ${currentPlayer}'s turn`;
        }
    }
}

function checkWin() {
    const winConditions = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ];

    for (let i = 0; i < winConditions.length; i++) {
        const [a, b, c] = winConditions[i];
        if (gameBoard[a] !== '' && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c]) {
            return true;
        }
    }

    return false;
}

function checkTie() {
    return gameBoard.every(cell => cell !== '');
}

function resetGame() {
    currentPlayer = 'X';
    gameBoard = ['', '', '', '', '', '', '', '', ''];
    gameOver = false;
    document.getElementById('game-status').innerHTML = `Player ${currentPlayer}'s turn`;
    for (let i = 1; i <= 9; i++) {
        document.getElementById(`cell-${i}`).innerHTML = '';
    }
    clearFireworks(); // Clear fireworks when the game resets
}

function showFireworks() {
    const gameContainer = document.querySelector('.game-container');
    
    // Create multiple fireworks
    for (let i = 0; i < 10; i++) {
        const firework = document.createElement('div');
        firework.classList.add('firework');
        firework.style.left = `${Math.random() * 100}%`;
        firework.style.top = `${Math.random() * 100}%`;
        firework.style.backgroundColor = getRandomColor();
        gameContainer.appendChild(firework);
        
        // Remove the firework after the animation ends
        setTimeout(() => {
            firework.remove();
        }, 500);
    }
}

function clearFireworks() {
    document.querySelectorAll('.firework').forEach(firework => firework.remove());
}

function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}
